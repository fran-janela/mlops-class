def say_hello(event, context):
    return {
        "created_by": "your name",
        "message": "Hello World!"
    }